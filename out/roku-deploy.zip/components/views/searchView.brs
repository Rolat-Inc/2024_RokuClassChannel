sub init()
    bindComponents()
    bindObservers()
end sub

sub bindComponents()
    m.miniKeyboard = m.top.findNode("miniKeyboard")
    m.button = m.top.findNode("button")
end sub

sub bindObservers()
    m.miniKeyboard.observeField("text", "onTextEntered")
end sub

sub onFocusedChildChange()
    if m.top.hasFocus() then m.miniKeyboard.setFocus(true)
end sub

sub onTextEntered(event as object)
    text = event.getData()
    ?"SV :: onTextEntered: ";text
    
    if Len(text) = 3 then
        ?"Debes crear el rowlist"
        'Crear rowlist
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
	handled = false
    
    ?"SearchView :: onKeyEvent, key: ";key;" - press: ";press
	if press then
		if key = "down" then
            if m.miniKeyboard.isInFocusChain() then
                m.button.setFocus(true)
                handled = true
            end if
        else if key = "up" then
            if m.button.hasFocus() then
                m.miniKeyboard.setFocus(true)
            end if
        end if
    end if

    return handled
end function